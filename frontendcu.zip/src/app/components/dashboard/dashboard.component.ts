import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, interval } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { DashboardService } from '../../services/dashboard.service';

export interface DashboardStats {
  totalPolicies: number;
  activePolicies: number;
  pendingPolicies: number;
  thisMonthPolicies: number;
  lastUpdated?: Date;
}

export interface RecentActivity {
  id: string;
  policyId: string;
  activity: string;
  timestamp: Date;
  status: 'success' | 'warning' | 'error' | 'info';
}

export interface QuickAction {
  title: string;
  description: string;
  icon: string;
  route: string;
  color: string;
}

@Component({
  selector: 'app-dashboard',
  standalone:false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  currentUser: any;
  loading = true;
  error = '';
  
  // Dashboard data
  stats: DashboardStats = {
    totalPolicies: 0,
    activePolicies: 0,
    pendingPolicies: 0,
    thisMonthPolicies: 0
  };
  
  recentActivities: RecentActivity[] = [];
  quickActions: QuickAction[] = [];
  
  // Subscriptions
  private subscriptions: Subscription[] = [];
  private refreshTimer?: Subscription;
  
  constructor(
    private authService: AuthService,
    private dashboardService: DashboardService,
    private router: Router
  ) {
    this.initializeQuickActions();
  }

  ngOnInit() {
    // Subscribe to current user
    const userSub = this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        this.loadDashboardData();
      } else {
        this.router.navigate(['/login']);
      }
    });
    this.subscriptions.push(userSub);
    
    // Auto refresh setiap 5 menit
    this.refreshTimer = interval(300000).subscribe(() => {
      this.refreshData();
    });
  }

  ngOnDestroy() {
    // Cleanup subscriptions
    this.subscriptions.forEach(sub => sub.unsubscribe());
    if (this.refreshTimer) {
      this.refreshTimer.unsubscribe();
    }
  }

  private initializeQuickActions() {
    this.quickActions = [
      {
        title: 'Consolidate Policy',
        description: 'Kelola dan lihat data policy consolidation',
        icon: 'bi-file-text',
        route: '/consolidate-policy',
        color: 'primary'
      },
      {
        title: 'Search Policy',
        description: 'Cari policy berdasarkan ID atau App No',
        icon: 'bi-search',
        route: '/consolidate-policy',
        color: 'success'
      },
      {
        title: 'Reports',
        description: 'Lihat laporan dan statistik',
        icon: 'bi-graph-up',
        route: '/reports',
        color: 'info'
      },
      {
        title: 'User Management',
        description: 'Kelola user dan permissions',
        icon: 'bi-people',
        route: '/users',
        color: 'warning'
      }
    ];
  }

  loadDashboardData() {
    this.loading = true;
    this.error = '';

    // Load statistics
    const statsSub = this.dashboardService.getDashboardStats(
      this.currentUser.userId, 
      this.currentUser.companyId
    ).subscribe({
      next: (stats) => {
        this.stats = {
          ...stats,
          lastUpdated: new Date()
        };
        this.loading = false;
      },
      error: (error) => {
        console.error('Failed to load dashboard stats:', error);
        this.loadMockData(); // Fallback to mock data
        this.loading = false;
      }
    });
    this.subscriptions.push(statsSub);

    // Load recent activities
    const activitiesSub = this.dashboardService.getRecentActivities(
      this.currentUser.userId,
      this.currentUser.companyId,
      10
    ).subscribe({
      next: (activities) => {
        this.recentActivities = activities;
      },
      error: (error) => {
        console.error('Failed to load recent activities:', error);
        this.loadMockActivities(); // Fallback to mock data
      }
    });
    this.subscriptions.push(activitiesSub);
  }

  private loadMockData() {
    // Mock data untuk development/fallback
    this.stats = {
      totalPolicies: 1234,
      activePolicies: 856,
      pendingPolicies: 234,
      thisMonthPolicies: 144,
      lastUpdated: new Date()
    };
  }

  private loadMockActivities() {
    // Mock activities untuk development/fallback
    this.recentActivities = [
      {
        id: '1',
        policyId: 'POL001',
        activity: 'Policy created successfully',
        timestamp: new Date(Date.now() - 60000),
        status: 'success'
      },
      {
        id: '2', 
        policyId: 'POL002',
        activity: 'Policy pending approval',
        timestamp: new Date(Date.now() - 300000),
        status: 'warning'
      },
      {
        id: '3',
        policyId: 'POL003',
        activity: 'Policy validation failed',
        timestamp: new Date(Date.now() - 900000),
        status: 'error'
      },
      {
        id: '4',
        policyId: 'POL004',
        activity: 'Policy updated',
        timestamp: new Date(Date.now() - 1800000),
        status: 'info'
      }
    ];
  }

  refreshData() {
    this.loadDashboardData();
  }

  navigateToQuickAction(action: QuickAction) {
    this.router.navigate([action.route]);
  }

  navigateToPolicy(policyId: string) {
    this.router.navigate(['/policy-detail', policyId]);
  }

  navigateToConsolidatePolicy() {
    this.router.navigate(['/consolidate-policy']);
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'success': return 'badge bg-success';
      case 'warning': return 'badge bg-warning';
      case 'error': return 'badge bg-danger';
      case 'info': return 'badge bg-info';
      default: return 'badge bg-secondary';
    }
  }

  getStatusIcon(status: string): string {
    switch (status) {
      case 'success': return 'bi-check-circle';
      case 'warning': return 'bi-exclamation-triangle';
      case 'error': return 'bi-x-circle';
      case 'info': return 'bi-info-circle';
      default: return 'bi-circle';
    }
  }

  formatRelativeTime(date: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMinutes < 1) return 'Baru saja';
    if (diffMinutes < 60) return `${diffMinutes} menit yang lalu`;
    if (diffHours < 24) return `${diffHours} jam yang lalu`;
    if (diffDays < 7) return `${diffDays} hari yang lalu`;
    
    return date.toLocaleDateString('id-ID');
  }

  // Chart data untuk future implementation
  getChartData() {
    return {
      labels: ['Active', 'Pending', 'Completed'],
      datasets: [{
        data: [this.stats.activePolicies, this.stats.pendingPolicies, 
               this.stats.totalPolicies - this.stats.activePolicies - this.stats.pendingPolicies],
        backgroundColor: ['#28a745', '#ffc107', '#17a2b8']
      }]
    };
  }
}
