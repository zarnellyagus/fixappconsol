import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, MenuItem } from '../../services/auth.service';

@Component({
  selector: 'app-layout',
  standalone:false,
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {
  currentUser: any;
  menus: MenuItem[] = [];
  sidebarCollapsed = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        this.menus = this.filterMenus(user.menus || []);
      } else {
        this.router.navigate(['/login']);
      }
    });
  }

  // Filter menu untuk menghindari duplikasi
  private filterMenus(userMenus: MenuItem[]): MenuItem[] {
    const staticMenuRoutes = ['/consolidate-policy', '/dashboard', '/reports', '/users'];
    return userMenus.filter(menu => !staticMenuRoutes.includes(menu.route));
  }

  toggleSidebar() {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  // Method untuk navigasi programmatic (jika diperlukan)
  navigateToConsolidatePolicy() {
    this.router.navigate(['/consolidate-policy']);
  }

  // Method untuk check active menu
  isMenuActive(route: string): boolean {
    return this.router.url === route;
  }
}
