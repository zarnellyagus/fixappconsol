import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService, PolicyRow, PolicyListResponse } from '../../services/policy.service';

@Component({
  selector: 'app-consolidate-policy',
  standalone:false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  policies: PolicyRow[] = [];
  loading = false;
  
  // Pagination
  currentPage = 1;
  pageSize = 10;
  totalCount = 0;
  totalPages = 0;
  pageSizeOptions = [10, 25, 50, 100];
  
  // Search
  searchPolicyId = '';
  searchAppNo = '';

  constructor(
    private policyService: PolicyService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadPolicies();
  }

  loadPolicies() {
    this.loading = true;
    
    const policyId = this.searchPolicyId.trim() || undefined;
    const appNo = this.searchAppNo.trim() || undefined;
    
    this.policyService.getPolicies(policyId, appNo, this.currentPage, this.pageSize)
      .subscribe({
        next: (response: PolicyListResponse) => {
          this.policies = response.data;
          this.totalCount = response.totalCount;
          this.totalPages = Math.ceil(this.totalCount / this.pageSize);
          this.loading = false;
        },
        error: (error) => {
          console.error('Failed to load policies:', error);
          this.loading = false;
        }
      });
  }

  onSearch() {
    this.currentPage = 1;
    this.loadPolicies();
  }

  onPageSizeChange() {
    this.currentPage = 1;
    this.loadPolicies();
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.loadPolicies();
    }
  }

  viewDetail(policyId: string) {
    this.router.navigate(['/policy-detail', policyId]);
  }

  getPageNumbers(): number[] {
    const pages: number[] = [];
    const start = Math.max(1, this.currentPage - 2);
    const end = Math.min(this.totalPages, this.currentPage + 2);
    
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    
    return pages;
  }
}
