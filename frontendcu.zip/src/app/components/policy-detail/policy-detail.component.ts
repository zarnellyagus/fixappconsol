import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PolicyService, PolicyDetail, PolicySummary } from '../../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  activeTab = 'policy-info';
  
  policyDetail: PolicyDetail | null = null;
  policySummary: PolicySummary | null = null;
  loading = false;
  error = '';

  constructor(
    private route: ActivatedRoute,
    private policyService: PolicyService
  ) {}

  ngOnInit() {
    this.policyId = this.route.snapshot.paramMap.get('id') ?? '';
    
    if (this.policyId) {
      this.loadPolicyDetail();
      this.loadPolicySummary();
    } else {
      this.error = 'Policy ID tidak ditemukan';
    }
  }

  loadPolicyDetail() {
    this.loading = true;
    this.error = '';
    
    this.policyService.getPolicyDetail(this.policyId).subscribe({
      next: (detail) => {
        this.policyDetail = detail;
        this.loading = false;
      },
      error: (error) => {
        console.error('Failed to load policy detail:', error);
        this.error = 'Gagal memuat detail policy';
        this.loading = false;
      }
    });
  }

  loadPolicySummary() {
    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (summary) => {
        this.policySummary = summary;
      },
      error: (error) => {
        console.error('Failed to load policy summary:', error);
      }
    });
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }

  // PERBAIKAN: Explicit boolean return dengan default false
  get hasPolicyDetail(): boolean {
    return this.policyDetail !== null && this.policyDetail !== undefined;
  }

  get hasPolicySummary(): boolean {
    return this.policySummary !== null && this.policySummary !== undefined;
  }

  get hasStatusList(): boolean {
    return Boolean(this.policySummary?.statusList?.length);
  }

  get hasSummaryDetail(): boolean {
    return Boolean(this.policySummary?.summaryDetail);
  }
}
