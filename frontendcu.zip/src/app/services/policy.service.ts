import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PolicyRow {
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: string;
}

export interface PolicyListResponse {
  data: PolicyRow[];
  totalCount: number;
  page: number;
  pageSize: number;
}

export interface PolicyDetail {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: string;
  agentId: string;
  branchName: string;
  addressName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface PolicySummary {
  statusList: PolicyStatus[];
  summaryDetail: PolicySummaryDetail;
}

export interface PolicyStatus {
  ePolSource: string;
  statusDate: string;
  ePolStatus: string;
}

export interface PolicySummaryDetail {
  polSumPolicyID: string;
  polSumPickUpDate: string;
  polSumStatusDate: string;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private readonly apiUrl = 'https://localhost:7119/api/consolidate';

  constructor(private http: HttpClient) { }

  getPolicies(policyId?: string, appNo?: string, page: number = 1, pageSize: number = 10): Observable<PolicyListResponse> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (policyId) params = params.set('policyId', policyId);
    if (appNo) params = params.set('appNo', appNo);

    return this.http.get<PolicyListResponse>(this.apiUrl, { params });
  }

  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    return this.http.get<PolicyDetail>(`${this.apiUrl}/${policyId}/detail`);
  }

  getPolicySummary(policyId: string): Observable<PolicySummary> {
    return this.http.get<PolicySummary>(`${this.apiUrl}/${policyId}/summary`);
  }
}
