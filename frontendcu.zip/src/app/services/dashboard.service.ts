import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface DashboardStats {
  totalPolicies: number;
  activePolicies: number;
  pendingPolicies: number;
  thisMonthPolicies: number;
}

export interface RecentActivity {
  id: string;
  policyId: string;
  activity: string;
  timestamp: Date;
  status: 'success' | 'warning' | 'error' | 'info';
}

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private readonly apiUrl = 'https://localhost:7119/api';

  constructor(private http: HttpClient) { }

  getDashboardStats(userId: string, companyId: string): Observable<DashboardStats> {
    const params = new HttpParams()
      .set('userId', userId)
      .set('companyId', companyId);

    return this.http.get<DashboardStats>(`${this.apiUrl}/dashboard/stats`, { params })
      .pipe(
        catchError(error => {
          console.error('Dashboard stats error:', error);
          // Return mock data sebagai fallback
          return of({
            totalPolicies: 1234,
            activePolicies: 856,
            pendingPolicies: 234,
            thisMonthPolicies: 144
          });
        })
      );
  }

  getRecentActivities(userId: string, companyId: string, limit: number = 10): Observable<RecentActivity[]> {
    const params = new HttpParams()
      .set('userId', userId)
      .set('companyId', companyId)
      .set('limit', limit.toString());

    return this.http.get<RecentActivity[]>(`${this.apiUrl}/dashboard/activities`, { params })
      .pipe(
        catchError(error => {
          console.error('Recent activities error:', error);
          // Return mock data sebagai fallback
          return of([
            {
              id: '1',
              policyId: 'POL001',
              activity: 'Policy created successfully',
              timestamp: new Date(Date.now() - 60000),
              status: 'success' as const
            },
            {
              id: '2',
              policyId: 'POL002', 
              activity: 'Policy pending approval',
              timestamp: new Date(Date.now() - 300000),
              status: 'warning' as const
            }
          ]);
        })
      );
  }
}
