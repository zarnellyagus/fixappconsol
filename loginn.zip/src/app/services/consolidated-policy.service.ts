import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  ConsolidatedPolicy, 
  PaginatedResult, 
  PolicyDetail, 
  EPolicy, 
  PolicySummary 
} from '../models/consolidated-policy.model';

@Injectable({
  providedIn: 'root'
})
export class ConsolidatedPolicyService {
  private http = inject(HttpClient);
  private apiUrl = 'https://localhost:7064/api/ConsolidatedPolicy';

  getConsolidatedPolicies(
    page: number = 1, 
    pageSize: number = 25, 
    policyId?: string, 
    appNo?: string
  ): Observable<PaginatedResult<ConsolidatedPolicy>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (policyId) {
      params = params.set('policyId', policyId);
    }
    if (appNo) {
      params = params.set('appNo', appNo);
    }

    return this.http.get<PaginatedResult<ConsolidatedPolicy>>(`${this.apiUrl}/list`, { params });
  }

  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    return this.http.get<PolicyDetail>(`${this.apiUrl}/detail/${policyId}`);
  }

  getEPolicy(policyId: string): Observable<EPolicy[]> {
    return this.http.get<EPolicy[]>(`${this.apiUrl}/epolicy/${policyId}`);
  }

  getPolicySummary(policyId: string): Observable<PolicySummary[]> {
    return this.http.get<PolicySummary[]>(`${this.apiUrl}/policysummary/${policyId}`);
  }
}
