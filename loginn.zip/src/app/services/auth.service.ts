// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { tap, catchError, timeout } from 'rxjs/operators';

export interface Company {
  CompanyID: string;
  CompanyName: string;
}

export interface LoginRequest {
  Username: string;
  Password: string;
  Company: string;
}

export interface UserData {
  UserId: string;
  companyID: string;
  companyName: string;
}

export interface MenuRole {
  Objectid: string;
  ObjectName: string;
  ObjectLink: string;
}

export interface LoginResponse {
  Success: boolean;
  Message: string;
  User?: UserData;
  MenuRoles?: MenuRole[];
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Coba kedua URL ini untuk debugging
  //private apiUrl = 'http://localhost:5000/api/Auth';  // HTTP version
   private apiUrl = 'https://localhost:7064/api'; // HTTPS version
  
  private currentUserSubject = new BehaviorSubject<UserData | null>(null);
  private menuRolesSubject = new BehaviorSubject<MenuRole[]>([]);

  public currentUser$ = this.currentUserSubject.asObservable();
  public menuRoles$ = this.menuRolesSubject.asObservable();

  constructor(private http: HttpClient) {
    console.log('🔧 AuthService initialized');
    console.log('📡 API URL:', this.apiUrl);
    this.testApiConnection();
  }

  // Test basic connectivity
  testApiConnection(): void {
    console.log('🧪 Testing API connection...');
    
    // Test jika server hidup
    this.http.get(`${this.apiUrl}/companies`, { 
      observe: 'response',
      responseType: 'json' as const
    })
    .pipe(
      timeout(10000), // 10 second timeout
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Connection test failed:', error);
        if (error.status === 0) {
          console.error('🔥 Possible issues:');
          console.error('   1. ASP.NET Core API is not running');
          console.error('   2. Wrong port number');
          console.error('   3. CORS not configured properly');
          console.error('   4. Firewall/antivirus blocking connection');
        }
        return throwError(() => error);
      })
    )
    .subscribe({
      next: (response) => {
        console.log('✅ API connection successful!');
        console.log('📊 Response status:', response.status);
        console.log('📦 Response headers:', response.headers);
        console.log('💾 Response body:', response.body);
      },
      error: (error) => {
        console.error('💥 Connection test error:', error);
      }
    });
  }

  getCompanies(): Observable<Company[]> {
    console.log('🏢 Fetching companies...');
    console.log('🌐 Request URL:', `${this.apiUrl}/companies`);
    
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.get<Company[]>(`${this.apiUrl}/companies`, { 
      headers,
      observe: 'body',
      responseType: 'json' as const
    })
    .pipe(
      timeout(15000), // 15 second timeout
      tap(companies => {
        console.log('✅ Companies loaded successfully!');
        console.log('📊 Number of companies:', companies?.length || 0);
        console.log('💾 Companies data:', companies);
      }),
      catchError((error: HttpErrorResponse) => this.handleDetailedError(error, 'getCompanies'))
    );
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    console.log('🔐 Attempting login...');
    console.log('👤 Username:', credentials.Username);
    console.log('🏢 Company:', credentials.Company);
    
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials, { headers })
      .pipe(
        timeout(15000),
        tap(response => {
          console.log('✅ Login response received:', response);
          if (response.Success && response.User) {
            this.currentUserSubject.next(response.User);
            this.menuRolesSubject.next(response.MenuRoles || []);
            localStorage.setItem('currentUser', JSON.stringify(response.User));
            localStorage.setItem('menuRoles', JSON.stringify(response.MenuRoles || []));
            console.log('💾 User data stored in localStorage');
          }
        }),
        catchError((error: HttpErrorResponse) => this.handleDetailedError(error, 'login'))
      );
  }

  logout(): Observable<any> {
    return this.http.post(`${this.apiUrl}/logout`, {})
      .pipe(
        tap(() => {
          this.currentUserSubject.next(null);
          this.menuRolesSubject.next([]);
          localStorage.removeItem('currentUser');
          localStorage.removeItem('menuRoles');
          console.log('👋 User logged out successfully');
        }),
        catchError((error: HttpErrorResponse) => this.handleDetailedError(error, 'logout'))
      );
  }

  getProfile(): Observable<UserData> {
    return this.http.get<UserData>(`${this.apiUrl}/profile`)
      .pipe(
        catchError((error: HttpErrorResponse) => this.handleDetailedError(error, 'getProfile'))
      );
  }

  getMenuRoles(): Observable<MenuRole[]> {
    return this.http.get<MenuRole[]>(`${this.apiUrl}/menu-roles`)
      .pipe(
        catchError((error: HttpErrorResponse) => this.handleDetailedError(error, 'getMenuRoles'))
      );
  }

  isLoggedIn(): boolean {
    return this.currentUserSubject.value !== null;
  }

  getCurrentUser(): UserData | null {
    return this.currentUserSubject.value;
  }

  initializeFromStorage(): void {
    const storedUser = localStorage.getItem('currentUser');
    const storedMenuRoles = localStorage.getItem('menuRoles');
    
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
      console.log('👤 User restored from localStorage');
    }
    if (storedMenuRoles) {
      this.menuRolesSubject.next(JSON.parse(storedMenuRoles));
      console.log('🎯 Menu roles restored from localStorage');
    }
  }

  private handleDetailedError(error: HttpErrorResponse, method: string): Observable<never> {
    console.group(`💥 HTTP Error in ${method}`);
    console.error('Full error object:', error);
    console.error('Error status:', error.status);
    console.error('Error statusText:', error.statusText);
    console.error('Error URL:', error.url);
    console.error('Error headers:', error.headers);
    
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      console.error('🖥️ Client-side error:', error.error.message);
      errorMessage = `Client Error: ${error.error.message}`;
    } else {
      // Server-side error
      console.error('🖥️ Server-side error');
      
      switch (error.status) {
        case 0:
          console.error('❌ Network Error - Possible causes:');
          console.error('   • ASP.NET Core API is not running');
          console.error('   • CORS not configured properly');
          console.error('   • Wrong URL or port');
          console.error('   • Firewall blocking request');
          errorMessage = 'Network Error: Cannot reach the server. Please check if the API is running.';
          break;
        case 404:
          console.error('❌ 404 Not Found - API endpoint does not exist');
          errorMessage = 'API endpoint not found. Check if the API is running and the URL is correct.';
          break;
        case 500:
          console.error('❌ 500 Internal Server Error');
          errorMessage = 'Internal server error. Check the API logs.';
          break;
        default:
          errorMessage = `Server Error: ${error.status} - ${error.statusText}`;
      }
    }
    
    console.error('📝 Final error message:', errorMessage);
    console.groupEnd();
    
    return throwError(() => new Error(errorMessage));
  }
}
