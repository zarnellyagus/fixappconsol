// src/app/components/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, Company, LoginRequest } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  companies: Company[] = [];
  loading = false;
  loadingCompanies = false;
  errorMessage = '';
  companiesError = '';
  debugInfo = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      Username: ['', Validators.required],
      Password: ['', Validators.required],
      Company: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    console.log('🚀 Login component initialized');
    
    // Check if already logged in
    if (this.authService.isLoggedIn()) {
      console.log('👤 User already logged in, redirecting...');
      this.router.navigate(['/dashboard']);
      return;
    }
    
    this.loadCompanies();
  }

  loadCompanies(): void {
    console.log('🏢 Starting to load companies...');
    this.loadingCompanies = true;
    this.companiesError = '';
    this.debugInfo = 'Loading companies...';
    
    this.authService.getCompanies().subscribe({
      next: (companies) => {
        console.log('✅ Companies loaded successfully in component:', companies);
        this.companies = companies;
        this.loadingCompanies = false;
        this.debugInfo = `Loaded ${companies.length} companies successfully`;
        
        if (companies.length === 0) {
          this.companiesError = 'No companies found in database';
          this.debugInfo = 'No companies available';
        }
      },
      error: (error) => {
        console.error('❌ Error loading companies in component:', error);
        this.loadingCompanies = false;
        this.companiesError = error.message || 'Failed to load companies';
        this.debugInfo = `Error: ${error.message}`;
        
        // Additional debugging info
        console.log('🔍 Debug checklist:');
        console.log('   1. Is ASP.NET Core API running?');
        console.log('   2. Is the API URL correct?');
        console.log('   3. Is CORS configured properly?');
        console.log('   4. Check browser Network tab for actual HTTP status');
      }
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.loading = true;
      this.errorMessage = '';
      
      const credentials: LoginRequest = this.loginForm.value;
      console.log('🔐 Submitting login form with:', { ...credentials, Password: '***' });
      
      this.authService.login(credentials).subscribe({
        next: (response) => {
          this.loading = false;
          console.log('✅ Login response in component:', response);
          
          if (response.Success) {
            console.log('🎉 Login successful, navigating to dashboard');
            this.router.navigate(['/dashboard']);
          } else {
            this.errorMessage = response.Message;
            console.log('❌ Login failed:', response.Message);
          }
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.message || 'Login failed. Please try again.';
          console.error('❌ Login error in component:', error);
        }
      });
    } else {
      console.log('❌ Form is invalid');
      Object.keys(this.loginForm.controls).forEach(key => {
        const control = this.loginForm.get(key);
        control?.markAsTouched();
        if (control?.errors) {
          console.log(`Field ${key} errors:`, control.errors);
        }
      });
    }
  }

  retryLoadCompanies(): void {
    console.log('🔄 Retrying to load companies...');
    this.loadCompanies();
  }

  // Method untuk debugging manual
  testApiConnection(): void {
    console.log('🧪 Manual API test triggered');
    this.debugInfo = 'Testing API connection...';
    
    fetch('https://localhost:7214/api/Auth/companies')
      .then(response => {
        console.log('🌐 Fetch response:', response);
        this.debugInfo = `Fetch test: ${response.status} ${response.statusText}`;
        return response.json();
      })
      .then(data => {
        console.log('📦 Fetch data:', data);
        this.debugInfo += ` | Data received: ${JSON.stringify(data)}`;
      })
      .catch(error => {
        console.error('💥 Fetch error:', error);
        this.debugInfo = `Fetch error: ${error.message}`;
      });
  }
}
