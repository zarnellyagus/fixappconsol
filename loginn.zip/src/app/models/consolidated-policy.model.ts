export interface ConsolidatedPolicy {
  no: number;
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: string;
}

export interface PaginatedResult<T> {
  data: T[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}

export interface PolicyDetail {
  spajNo: string;
  policyNo: string;
  policyStatus: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: string;
  agentID: string;
  agentName: string;
  branchName: string;
  address: string;
  email: string;
  phoneNumber: string;
  ttp: string;
  receiveDate: string;
}

export interface EPolicy {
  ePolSource: string;
  statusDate: string;
  status: string;
}

export interface PolicySummary {
  polSumPolicyID: string;
  polSumPickUpDate: string;
  polSumStatusDate: string;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}
