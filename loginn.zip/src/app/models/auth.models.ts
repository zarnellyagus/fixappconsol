// models/auth.models.ts
export interface LoginRequest {
  username: string;
  password: string;
  company: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  user?: UserData;
  menuRoles?: MenuRole[];
}

export interface UserData {
  userId: string;
  company: string;
  companyName: string;
}

export interface MenuRole {
  objectId: string;
  objectName: string;
  objectLink: string;
}

export interface Company {
  companyID: string;
  companyName: string;
}
