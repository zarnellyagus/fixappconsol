import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  ConsolidatePolicyRequest, 
  ConsolidatePolicyResponse, 
  PolicyDetail, 
  PolicyStatus, 
  PolicySummary 
} from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'https://localhost:7264/api/policy';

  constructor(private http: HttpClient) { }

  getConsolidatePolicies(request: ConsolidatePolicyRequest): Observable<ConsolidatePolicyResponse> {
    let params = new HttpParams()
      .set('page', request.page.toString())
      .set('pageSize', request.pageSize.toString());

    if (request.policyId) {
      params = params.set('policyId', request.policyId);
    }
    if (request.appNo) {
      params = params.set('appNo', request.appNo);
    }

    return this.http.get<ConsolidatePolicyResponse>(`${this.apiUrl}/consolidate`, { params });
  }

  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    return this.http.get<PolicyDetail>(`${this.apiUrl}/detail/${policyId}`);
  }

  getPolicyStatus(policyId: string): Observable<PolicyStatus[]> {
    return this.http.get<PolicyStatus[]>(`${this.apiUrl}/status/${policyId}`);
  }

  getPolicySummary(policyId: string): Observable<PolicySummary[]> {
    return this.http.get<PolicySummary[]>(`${this.apiUrl}/summary/${policyId}`);
  }
}
