import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoginRequest, LoginResponse, Company, UserInfo, MenuObject } from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:7264/api';
  private currentUserSubject = new BehaviorSubject<UserInfo | null>(null);
  private menuItemsSubject = new BehaviorSubject<MenuObject[]>([]);

  public currentUser$ = this.currentUserSubject.asObservable();
  public menuItems$ = this.menuItemsSubject.asObservable();

  constructor(private http: HttpClient) {
    // Check if user is already logged in
    const storedUser = localStorage.getItem('currentUser');
    const storedMenu = localStorage.getItem('menuItems');
    
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
    if (storedMenu) {
      this.menuItemsSubject.next(JSON.parse(storedMenu));
    }
  }

  login(loginRequest: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/auth/login`, loginRequest)
      .pipe(
        tap(response => {
          if (response.success && response.userInfo) {
            localStorage.setItem('currentUser', JSON.stringify(response.userInfo));
            localStorage.setItem('menuItems', JSON.stringify(response.menuItems || []));
            this.currentUserSubject.next(response.userInfo);
            this.menuItemsSubject.next(response.menuItems || []);
          }
        })
      );
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('menuItems');
    this.currentUserSubject.next(null);
    this.menuItemsSubject.next([]);
  }

  getCompanies(): Observable<Company[]> {
    return this.http.get<Company[]>(`${this.apiUrl}/auth/companies`);
  }

  get currentUserValue(): UserInfo | null {
    return this.currentUserSubject.value;
  }

  get isLoggedIn(): boolean {
    return this.currentUserValue !== null;
  }
}
