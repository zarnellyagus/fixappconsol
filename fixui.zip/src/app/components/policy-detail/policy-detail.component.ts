import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';
import { lastValueFrom, of, EMPTY } from 'rxjs';
import { PolicyService } from '../../services/policy.service';
import { PolicyDetail, PolicyStatus, PolicySummary } from '../../models/auth.model';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit, OnDestroy {
  policyId: string = '';
  policyDetail: PolicyDetail | null = null;
  policyStatuses: PolicyStatus[] = [];
  policySummaries: PolicySummary[] = [];
  
  isLoading: boolean = false;
  errorMessage: string = '';
  activeTab: string = 'policy-info';
  
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private policyService: PolicyService
  ) { }

  ngOnInit(): void {
    // Get policy ID from route parameters
    this.route.params
      .pipe(takeUntil(this.destroy$))
      .subscribe(params => {
        this.policyId = params['id'];
        if (this.policyId) {
          this.loadPolicyData();
        } else {
          this.errorMessage = 'Policy ID tidak ditemukan';
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadPolicyData(): void {
    this.isLoading = true;
    this.errorMessage = '';

    // Load all policy data concurrently
    Promise.all([
      this.loadPolicyDetail(),
      this.loadPolicyStatus(),
      this.loadPolicySummary()
    ]).finally(() => {
      this.isLoading = false;
    });
  }

  private async loadPolicyDetail(): Promise<void> {
    try {
      // Use lastValueFrom instead of toPromise()
      const detail = await lastValueFrom(
        this.policyService.getPolicyDetail(this.policyId).pipe(
          catchError((error) => {
            console.error('Error loading policy detail:', error);
            return of(null); // Return null on error instead of undefined
          })
        )
      );
      
      this.policyDetail = detail ?? null; // Ensure null instead of undefined
      
      if (!this.policyDetail) {
        this.errorMessage = 'Detail policy tidak ditemukan';
      }
    } catch (error) {
      console.error('Error loading policy detail:', error);
      this.errorMessage = 'Gagal memuat detail policy';
      this.policyDetail = null;
    }
  }

  private async loadPolicyStatus(): Promise<void> {
    try {
      const statuses = await lastValueFrom(
        this.policyService.getPolicyStatus(this.policyId).pipe(
          catchError((error) => {
            console.error('Error loading policy status:', error);
            return of([]); // Return empty array on error
          })
        )
      );
      
      this.policyStatuses = statuses || [];
    } catch (error) {
      console.error('Error loading policy status:', error);
      this.policyStatuses = [];
    }
  }

  private async loadPolicySummary(): Promise<void> {
    try {
      const summaries = await lastValueFrom(
        this.policyService.getPolicySummary(this.policyId).pipe(
          catchError((error) => {
            console.error('Error loading policy summary:', error);
            return of([]); // Return empty array on error
          })
        )
      );
      
      this.policySummaries = summaries || [];
    } catch (error) {
      console.error('Error loading policy summary:', error);
      this.policySummaries = [];
    }
  }

  onTabChange(tabId: string): void {
    this.activeTab = tabId;
  }

  goBack(): void {
    this.router.navigate(['/dashboard/consolidate-policy']);
  }

  formatDate(date: Date | string | null | undefined): string {
    if (!date) return '-';
    
    try {
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(dateObj.getTime())) return '-';
      
      return dateObj.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
    } catch {
      return '-';
    }
  }

  formatDateTime(date: Date | string | null | undefined): string {
    if (!date) return '-';
    
    try {
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      if (isNaN(dateObj.getTime())) return '-';
      
      return dateObj.toLocaleString('id-ID', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return '-';
    }
  }

  getDisplayValue(value: any): string {
    // Handle null, undefined, empty string
    if (value === null || value === undefined || value === '') {
      return '-';
    }
    return String(value);
  }

  // Type guard untuk memastikan policyDetail tidak null
  hasPolicyDetail(): this is { policyDetail: PolicyDetail } {
    return this.policyDetail !== null;
  }
}
