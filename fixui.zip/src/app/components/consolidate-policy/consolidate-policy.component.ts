import { Component, OnInit } from '@angular/core';
import { PolicyService } from '../../services/policy.service';
import { ConsolidatePolicyRequest, ConsolidatePolicyResponse } from '../../models/auth.model';

@Component({
  selector: 'app-consolidate-policy',
  standalone:false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  searchRequest: ConsolidatePolicyRequest = {
    policyId: '',
    appNo: '',
    page: 1,
    pageSize: 10
  };

  policyResponse: ConsolidatePolicyResponse | null = null;
  isLoading: boolean = false;

  constructor(private policyService: PolicyService) { }

  ngOnInit(): void {
    this.loadData();
  }

  // Method utama untuk load data
  loadData(): void {
    this.isLoading = true;
    
    console.log('Loading data with request:', this.searchRequest); // Debug log
    
    this.policyService.getConsolidatePolicies(this.searchRequest).subscribe({
      next: (response) => {
        console.log('Response received:', response); // Debug log
        this.policyResponse = response;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading policies:', error);
        this.isLoading = false;
        this.policyResponse = {
          data: [],
          totalRecords: 0,
          totalPages: 0,
          currentPage: 1
        };
      }
    });
  }

  // Method untuk pencarian
  search(): void {
    console.log('Search triggered'); // Debug log
    this.searchRequest.page = 1; // Reset ke halaman pertama saat search
    this.loadData();
  }

  // Method untuk reset
  reset(): void {
    this.searchRequest = {
      policyId: '',
      appNo: '',
      page: 1,
      pageSize: this.searchRequest.pageSize
    };
    this.loadData();
  }

  // Method untuk change page size
  changePageSize(): void {
    console.log('Page size changed to:', this.searchRequest.pageSize); // Debug log
    this.searchRequest.page = 1; // Reset ke halaman pertama
    this.loadData();
  }

  // Method untuk pindah halaman - PERBAIKAN UTAMA
  goToPage(page: number): void {
    console.log('GoToPage called with page:', page); // Debug log
    console.log('Current policyResponse:', this.policyResponse); // Debug log
    
    // Validasi input page
    if (!this.policyResponse) {
      console.error('PolicyResponse is null');
      return;
    }

    // Validasi range halaman
    if (page < 1 || page > this.policyResponse.totalPages) {
      console.error('Page out of range:', page, 'Total pages:', this.policyResponse.totalPages);
      return;
    }

    // Jangan load ulang jika sudah di halaman yang sama
    if (page === this.policyResponse.currentPage) {
      console.log('Already on page:', page);
      return;
    }

    // Update page number dan load data
    this.searchRequest.page = page;
    console.log('Updated searchRequest:', this.searchRequest); // Debug log
    this.loadData();
  }

  // Method untuk mendapatkan nomor halaman untuk pagination
  getPageNumbers(): number[] {
    if (!this.policyResponse) return [];
    
    const totalPages = this.policyResponse.totalPages;
    const currentPage = this.policyResponse.currentPage;
    const pages: number[] = [];
    
    // Tampilkan maksimal 5 nomor halaman
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    
    // Adjust start page jika mendekati akhir
    if (endPage - startPage < 4) {
      startPage = Math.max(1, endPage - 4);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    
    console.log('Page numbers:', pages, 'Current:', currentPage, 'Total:', totalPages); // Debug log
    return pages;
  }

  // Helper methods untuk pagination info
  getStartRecord(): number {
    if (!this.policyResponse) return 0;
    return ((this.policyResponse.currentPage - 1) * this.searchRequest.pageSize) + 1;
  }

  getEndRecord(): number {
    if (!this.policyResponse) return 0;
    const end = this.policyResponse.currentPage * this.searchRequest.pageSize;
    return Math.min(end, this.policyResponse.totalRecords);
  }

  getRowNumber(index: number): number {
    return ((this.searchRequest.page - 1) * this.searchRequest.pageSize) + index + 1;
  }

  // Helper methods untuk pagination state
  canGoPrevious(): boolean {
    return this.policyResponse ? this.policyResponse.currentPage > 1 : false;
  }

  canGoNext(): boolean {
    return this.policyResponse ? this.policyResponse.currentPage < this.policyResponse.totalPages : false;
  }
}
