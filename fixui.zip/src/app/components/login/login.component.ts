import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { LoginRequest, Company } from '../../models/auth.model';

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginRequest: LoginRequest = {
    username: '',
    password: '',
    companyID: ''
  };

  companies: Company[] = [];
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // Redirect if already logged in
    if (this.authService.isLoggedIn) {
      this.router.navigate(['/dashboard']);
      return;
    }

    this.loadCompanies();
  }

  loadCompanies(): void {
    this.authService.getCompanies().subscribe({
      next: (companies) => {
        this.companies = companies;
      },
      error: (error) => {
        console.error('Error loading companies:', error);
        this.errorMessage = 'Gagal memuat data company';
      }
    });
  }

  onLogin(): void {
    this.errorMessage = '';
    
    if (!this.loginRequest.username || !this.loginRequest.password || !this.loginRequest.companyID) {
      this.errorMessage = 'Semua field harus diisi';
      return;
    }

    this.isLoading = true;

    this.authService.login(this.loginRequest).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.router.navigate(['/dashboard']);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.error?.message || 'Terjadi kesalahan saat login';
      }
    });
  }
}
