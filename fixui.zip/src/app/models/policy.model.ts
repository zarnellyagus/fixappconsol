export interface ConsolidatePolicy {
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate: Date;
}

export interface PagedResult<T> {
  data: T[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}

export interface PolicyDetail {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: Date;
  agentId: string;
  branchName: string;
  addressName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface PolicyStatusInfo {
  ePolSource: string;
  statusDate: Date;
  statusData: string;
}

export interface PolicySummaryInfo {
  polSumPolicyID: string;
  polSumPickUpDate: Date;
  polSumStatusDate: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}
