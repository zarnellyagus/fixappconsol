export interface LoginRequest {
  username: string;
  password: string;
  companyID: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  userInfo?: UserInfo;
  menuItems?: MenuObject[];
}

export interface UserInfo {
  userID: string;
  companyID: string;
  companyName: string;
}

export interface Company {
  companyID: string;
  companyName: string;
}

export interface MenuObject {
  objectID: string;
  objectName: string;
}

export interface ConsolidatePolicyRequest {
  policyId?: string;
  appNo?: string;
  page: number;
  pageSize: number;
}

export interface ConsolidatePolicyResponse {
  data: ConsolidatePolicy[];
  totalRecords: number;
  totalPages: number;
  currentPage: number;
}

export interface ConsolidatePolicy {
  no: number;
  companyID: string;
  policyID: string;
  appNo: string;
  ownerName: string;
  issuedDate?: Date;
}

export interface PolicyDetail {
  spajNo: string;
  policyNo: string;
  clientID: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate?: Date;
  agentId: string;
  branchName: string;
  addressName: string;
  email: string;
  tlpNum: string;
  ttp: string;
  receiveDate: string;
}

export interface PolicyStatus {
  ePolSource: string;
  statusDate: Date;
  status: string;
}

export interface PolicySummary {
  polSumPolicyID: string;
  polSumPickUpDate?: Date;
  polSumStatusDate?: Date;
  polSumStatus: string;
  polSumReceiver: string;
  polSumRelation: string;
  polSumReturn: string;
  polSumResiNo: string;
  polSumCourier: string;
}
